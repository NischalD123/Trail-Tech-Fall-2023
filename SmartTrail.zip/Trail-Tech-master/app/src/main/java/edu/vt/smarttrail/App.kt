package edu.vt.smarttrail

import android.graphics.drawable.Drawable

// Class that represents an App instance
class App(var appIcon: Drawable, var appName: String, var usagePercentage: Int, var usageDuration: String)