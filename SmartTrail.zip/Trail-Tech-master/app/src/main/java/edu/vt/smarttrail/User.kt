package edu.vt.smarttrail

data class User(var primaryKey: String, var username: String, var email: String, var password: String, var usageStats: String)