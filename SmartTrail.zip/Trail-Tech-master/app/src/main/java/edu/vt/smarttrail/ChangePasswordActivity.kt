package edu.vt.smarttrail

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import android.view.View.OnFocusChangeListener
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.database.FirebaseDatabase

class ChangePasswordActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_change_password)

        // Creates an action bar, where back button is.
        val actionBar = supportActionBar

        // Creates back button.
        actionBar!!.setDisplayHomeAsUpEnabled(true)

        val firebaseCloud = FirebaseDatabase.getInstance().getReference("users")

        val extras = intent.extras
        var key:String? = null
//        var userID:String? = "NotFound"
//        var password:String? = "NotFound"
//        var email:String? = "NotFound"
        if (extras != null) {
            key = extras.getString("primary_key")
//            userID = extras.getString("userID")
//            password = extras.getString("password")
//            email = extras.getString("email")
        }


        val newPasswordText = findViewById<View>(R.id.new_password) as TextInputEditText
        newPasswordText.onFocusChangeListener = OnFocusChangeListener { v, hasFocus ->
            if (!hasFocus) {
                hideKeyboard(v)
            }
        }

        val submit = findViewById<View>(R.id.submit_password) as Button
        submit.setOnClickListener {
            val newPassword = newPasswordText.text.toString()

            if (newPassword.isEmpty()) {
                Toast.makeText(this, "Fill the fields.", Toast.LENGTH_SHORT).show()
            }
            else {
                if (key != null) {
                    //SQLite DB
                    val login_db:DBHelper = DBHelper(this)
                    Log.e("SIN", "${key}")
                    val user = login_db.getUser(key!!)
                    Log.e("SIN", "${user.password}")
                    login_db.changePassword(user.primaryKey, user.username, user.usageStats, user.email, newPassword)
                    firebaseCloud.child(key).child("password").setValue(newPassword)

                    Toast.makeText(this, "Password Changed", Toast.LENGTH_SHORT).show()

                    val sharedPre = getSharedPreferences("autoLogin", Context.MODE_PRIVATE)
                    sharedPre.edit().putString("key", null).apply()
                    val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)
                }
            }

        }
    }

    // Hides keyboard.
    private fun hideKeyboard(view: View) {
        val inputMethodManager: InputMethodManager =
            getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        inputMethodManager.hideSoftInputFromWindow(view.windowToken, 0)
    }
}