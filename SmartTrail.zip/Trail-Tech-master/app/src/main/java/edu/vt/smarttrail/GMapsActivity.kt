package edu.vt.smarttrail
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Location
import android.os.Bundle
import android.util.Log
import android.widget.Button
//import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import edu.vt.smarttrail.databinding.ActivityGmapsBinding
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.*
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import java.util.*
import edu.vt.smarttrail.surveyactivity.FullMapActivity

class CustomLocation {
    var latitude: Double = 0.0
    var longitude: Double = 0.0

    constructor() // Default constructor required for Firebase

    constructor(latitude: Double, longitude: Double) {
        this.latitude = latitude
        this.longitude = longitude
    }
}


open class GMapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mapFragment: SupportMapFragment
    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityGmapsBinding
    private var mLastKnownLocation: Location? = null;

    companion object {
        const val MY_PERMISSIONS_REQUEST_LOCATION = 123
        private const val LOCATION_PATH = "locations"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gmaps)

        mapFragment = supportFragmentManager.findFragmentById(edu.vt.smarttrail.R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        // Get the button view
        val fullMapButton = findViewById<Button>(R.id.back_button)

        // Set a click listener for the button
        fullMapButton.setOnClickListener {
            val newintent = Intent(this, FullMapActivity::class.java)
            startActivity(newintent)
        }

    }

    override fun onMapReady(map: GoogleMap) {
        mMap = map

        var uid = UidSingleton.getUid()

        Log.d(FullMapActivity.TAG, "fma uid: ${uid}")

        // Add markers and polylines for survey responses
        val database = Firebase.database.reference
        val surveyResponsesRef = uid?.let { database.child("users_responses").child(it) }

        surveyResponsesRef?.orderByKey()?.limitToLast(2)?.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                // Create a LatLng object for the previous location
                var previousLocation: LatLng? = null

                // Loop through each child node of the "survey_responses" node
                for (childSnapshot in snapshot.children) {
                    // Get the latitude, longitude, and timestamp values
                    val latitude = childSnapshot.child("latitude").getValue(Double::class.java)
                    val longitude = childSnapshot.child("longitude").getValue(Double::class.java)
                    var timestamp = childSnapshot.child("timestamp").getValue(String::class.java)

                    // Create a LatLng object from the latitude and longitude values
                    val location = LatLng(latitude ?: 0.0, longitude ?: 0.0)

                    // Create a MarkerOptions object for the marker
                    val markerOptions = MarkerOptions()
                        .position(location)
                        .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE)).title("Survey response " + uid).snippet(
                            timestamp)

                    // Add the marker to the map
                    mMap.addMarker(markerOptions)

                    // If this is not the first location, add a polyline from the previous location to the current location
                    if (previousLocation != null) {
                        val polylineOptions = PolylineOptions()
                            .add(previousLocation, location)
                            .color(Color.BLUE)
                        mMap.addPolyline(polylineOptions)
                    }

                    // Set the current location as the previous location for the next iteration
                    previousLocation = location
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Failed to read value
                Log.w(FullMapActivity.TAG, "Failed to read value.", error.toException())
            }
        })

        // enable my location button
        mMap.uiSettings.isMyLocationButtonEnabled = true

        // get latlong for corners for specified place
        val one = LatLng(46.17, -85.0) //sw corner
        val two = LatLng(34.0, -68.0) //ne corner
        val builder = LatLngBounds.Builder()

        //add them to builder
        builder.include(one)
        builder.include(two)
        val bounds = builder.build()

        //get width and height to current display screen
        val width = resources.displayMetrics.widthPixels
        val height = resources.displayMetrics.heightPixels

        // 20% padding
        val padding = (width * 0.10).toInt()

        //set latlong bounds
        mMap!!.setLatLngBoundsForCameraTarget(bounds)

        //move camera to fill the bound to screen
        mMap!!.moveCamera(CameraUpdateFactory.newLatLngBounds(bounds, width, height, padding))


        // enable my location
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            == PackageManager.PERMISSION_GRANTED) {
            mMap.isMyLocationEnabled = true
        } else {
            // request permission
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                edu.vt.smarttrail.GMapsActivity.Companion.MY_PERMISSIONS_REQUEST_LOCATION
            )
        }

    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        when (requestCode) {
            edu.vt.smarttrail.GMapsActivity.Companion.MY_PERMISSIONS_REQUEST_LOCATION -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // permission granted, enable my location
                    if (ActivityCompat.checkSelfPermission(
                            this,
                            Manifest.permission.ACCESS_FINE_LOCATION
                        ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                            this,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                        ) != PackageManager.PERMISSION_GRANTED
                    ) {
                        return
                    }
                    mMap.isMyLocationEnabled = true
                } else {
                    // permission denied
                    Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show()
                }
            }
            else -> super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        }
    }


}