package edu.vt.smarttrail


data class AppStats(var primaryKey: String, var pushKey: String, var date: String, var usageStats: String)
