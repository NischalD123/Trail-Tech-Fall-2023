package edu.vt.smarttrail

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.Toast

class ScreentimePermissionActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screentime_permission)

        // Creates an action bar, where back button is.
        val actionBar = supportActionBar

        // Creates back button.
        actionBar!!.setDisplayHomeAsUpEnabled(true)

        val requestButton = findViewById<View>(R.id.request_screentime) as Button
        val agreeCheck = findViewById<View>(R.id.screentime_check) as CheckBox
        val readCheck = findViewById<View>(R.id.screentime_check_terms) as CheckBox
        requestButton.setOnClickListener{
            if (agreeCheck.isChecked && readCheck.isChecked) {
                startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            }
            else {
                Toast.makeText(this@ScreentimePermissionActivity, "Please indicate you agree to the terms and policies.", Toast.LENGTH_LONG).show()
            }
        }
        val backtoLocationsPermission = findViewById<View>(R.id.back_to_request_location) as Button
        backtoLocationsPermission.setOnClickListener()
        {
            val intent = Intent(this, edu.vt.smarttrail.LocationPermissionActivity::class.java)
            startActivity(intent)
        }


    }


}