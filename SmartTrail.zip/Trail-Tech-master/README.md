# Trail-Tech
This project focuses on gathering user-related data over long-distance hiking to study hikers' digital well-being, how technology affects hiking experiences, and promoting user-centered trail management.


# Development setup
To work on the codebase or install the current development version, clone this repository and open it as a project in Android Studio.
